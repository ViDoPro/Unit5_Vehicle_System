<?php
require_once "Vehicle.php";

class Car extends Vehicle {

    private $numberOfDoors;

    public function __construct($brand, $model, $year, $price, $doors) {
        parent::__construct($brand, $model, $year, $price);
        $this->numberOfDoors = $doors;
    }

    public function displayInfo() {
        parent::displayInfo();
        echo "Doors: $this->numberOfDoors <br>";
    }
}