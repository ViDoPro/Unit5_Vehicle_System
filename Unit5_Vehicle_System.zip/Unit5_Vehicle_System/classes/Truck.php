<?php
require_once "Vehicle.php";

class Truck extends Vehicle {

    private $cargoCapacity;

    public function __construct($brand, $model, $year, $price, $cargo) {
        parent::__construct($brand, $model, $year, $price);
        $this->cargoCapacity = $cargo;
    }

    public function displayInfo() {
        parent::displayInfo();
        echo "Cargo Capacity: $this->cargoCapacity <br>";
    }
}