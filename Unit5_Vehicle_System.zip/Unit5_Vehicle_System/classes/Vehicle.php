<?php

class Vehicle {

    protected $brand;
    protected $model;
    protected $year;
    protected $price;

    public static $count = 0;

    public function __construct($brand, $model, $year, $price) {
        $this->brand = $brand;
        $this->model = $model;
        $this->year = $year;
        $this->price = $price;

        self::$count++;
    }

    public function displayInfo() {
        echo "Brand: $this->brand <br>";
        echo "Model: $this->model <br>";
        echo "Year: $this->year <br>";
        echo "Price: $this->price <br>";
    }

    public function comparePrice($otherVehicle) {
        return $this->price - $otherVehicle->price;
    }
}