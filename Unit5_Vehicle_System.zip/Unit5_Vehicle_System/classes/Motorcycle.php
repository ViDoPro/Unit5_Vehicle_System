<?php
require_once "Vehicle.php";

class Motorcycle extends Vehicle {

    private $handlebarType;

    public function __construct($brand, $model, $year, $price, $handlebar) {
        parent::__construct($brand, $model, $year, $price);
        $this->handlebarType = $handlebar;
    }

    public function displayInfo() {
        parent::displayInfo();
        echo "Handlebar Type: $this->handlebarType <br>";
    }
}