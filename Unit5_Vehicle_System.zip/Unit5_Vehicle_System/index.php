<link rel="stylesheet" href="style.css">

<div class="container">

<form method="POST" action="process.php">

    <label>Brand:</label>
    <input type="text" name="brand" required>

    <label>Model:</label>
    <input type="text" name="model" required>

    <label>Year:</label>
    <input type="number" name="year" required>

    <label>Price:</label>
    <input type="number" name="price" required>

    <label>Vehicle Type:</label>
    <select name="type">
        <option value="car">Car</option>
        <option value="truck">Truck</option>
        <option value="motorcycle">Motorcycle</option>
    </select>

    <label>Doors (Car only)</label>
    <input type="number" name="doors">

    <label>Cargo (Truck only)</label>
    <input type="text" name="cargo">

    <label>Handlebar (Motorcycle only)</label>
    <input type="text" name="handlebar">

    <button type="submit">Create Vehicle</button>

</form>

</div>