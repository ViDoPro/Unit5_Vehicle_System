Unit5_Vehicle_System/
│
├── classes/
│   ├── Vehicle.php
│   ├── Car.php
│   ├── Truck.php
│   ├── Motorcycle.php
│
├── index.php
├── process.php
├── style.css

Link : http://localhost/Unit5_Vehicle_System/