<?php

require_once "classes/Vehicle.php";
require_once "classes/Car.php";
require_once "classes/Truck.php";
require_once "classes/Motorcycle.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $brand = $_POST["brand"];
    $model = $_POST["model"];
    $year = $_POST["year"];
    $price = $_POST["price"];
    $type = $_POST["type"];

    echo "
    <!DOCTYPE html>
    <html>
    <head>
        <title>Vehicle Output</title>
        <link rel='stylesheet' href='style.css'>
    </head>
    <body>

    <div class='container'>

        <div class='header-bar'>
            <a href='index.php' class='back-btn'>← Back</a>
            <h2 class='output-title'>Your Product is Ready</h2>
        </div>

        <div class='output'>
    ";

    // CREATE OBJECT
    if ($type == "car") {

        $vehicle = new Car(
            $brand,
            $model,
            $year,
            $price,
            $_POST["doors"]
        );

    } elseif ($type == "truck") {

        $vehicle = new Truck(
            $brand,
            $model,
            $year,
            $price,
            $_POST["cargo"]
        );

    } else {

        $vehicle = new Motorcycle(
            $brand,
            $model,
            $year,
            $price,
            $_POST["handlebar"]
        );
    }

    // OUTPUT FIELDS
    echo "<div class='vehicle-field'><span>Brand:</span> $brand</div>";
    echo "<div class='vehicle-field'><span>Model:</span> $model</div>";
    echo "<div class='vehicle-field'><span>Year:</span> $year</div>";
    echo "<div class='vehicle-field'><span>Price:</span> $price</div>";

    // UNIQUE FIELDS
    if ($type == "car") {

        echo "<div class='vehicle-field'><span>Doors:</span> " . $_POST["doors"] . "</div>";

    } elseif ($type == "truck") {

        echo "<div class='vehicle-field'><span>Cargo Capacity:</span> " . $_POST["cargo"] . "</div>";

    } else {

        echo "<div class='vehicle-field'><span>Handlebar Type:</span> " . $_POST["handlebar"] . "</div>";
    }

    // TOTAL COUNT
    echo "
        <div class='total-box'>
            Total Vehicles Created: " . Vehicle::$count . "
        </div>
    ";

    echo "
        </div>
    </div>

    </body>
    </html>
    ";
}
?>